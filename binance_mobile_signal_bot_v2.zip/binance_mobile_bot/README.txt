BINANCE SIGNAL BOT V2 — мобильная версия

Что есть:
- BTC, ETH, BNB, SOL, XRP, LTC
- 15s и 30s через live-поток сделок Binance
- 1m, 3m, 5m, 15m, 1h, 4h через Binance Kline API
- RSI, EMA20, EMA50, MACD, объём
- шкала сигнала от -100 до +100
- BUY / SELL / WAIT
- мульти-таймфрейм
- примерные Entry / Stop Loss / TP1 / TP2
- без API-ключей и без автоторговли

Важно: 15s/30s требуют LIVE и нескольких секунд накопления сделок. Все сигналы технические и не гарантируют прибыль.
